const fs = require('fs')

global.owner = ["62887435047326"]
global.push_kontak_delay = 5000 //5 detik, 1000 = 1 detik
global.pairingNumber = ""